 
<?php $__env->startSection('content'); ?>

<!-- Header end -->
<div class="authpages">
  <div class="container">
    <div class="row">
      <div class="col-lg-5">
        <div class="useraccountwrap">
          <div class="userccount whitebg">
              <div class="formpanel mt-2">
                <div class="socialLogin">
                  <h5><?php echo e(__('Verify OTP')); ?></h5>
                </div>
                <form class="form-horizontal" method="POST" action="<?php echo e(route('user.postVerifyOTP')); ?>">
                  <?php echo e(csrf_field()); ?>

                  <div class="formpanel">
                    <div class="formrow<?php echo e($errors->has('otp') ? ' has-error' : ''); ?>">
                      <input id="otp" type="text" class="form-control" name="otp" value="" autofocus placeholder="<?php echo e(__('OTP')); ?>"> 
                      <?php if($errors->has('otp')): ?>
                        <span class="help-block mt-4">
                            <strong><?php echo e($errors->first('otp')); ?></strong>
                        </span>
                      <?php endif; ?>
                      
                      <?php if(session('otp_sent_success')): ?>
                        <div class="text-success mt-4">
                            <?php echo e(session('otp_sent_success')); ?>

                        </div>
                    <?php endif; ?>
                    </div>
                    <div class="formpanel">

                    <input type="submit" class="btn btn-success" value="<?php echo e(__('Verify')); ?>">
                    </div>
                  </div>
                  <!-- login form  end-->
                </form>
                
                <form class="mt-2" method="POST" action="<?php echo e(route('user.resndOTP')); ?>">
                  <?php echo e(csrf_field()); ?>

                  <div class="formpanel">
                    <input type="submit" class="btn btn-info" value="<?php echo e(__('Resend')); ?>">
                  </div>
                  <!-- login form  end-->
                </form>
                
                <!-- sign up form -->
                <div class="newuser">
                    <div class="newuser"><i class="fas fa-user" aria-hidden="true"></i> <?php echo e(__('Have Account')); ?>? <a href="<?php echo e(route('login')); ?>"><?php echo e(__('Sign in')); ?></a></div>
                </div>
                <!-- sign up form end-->
              </div>
            </div>
            <!-- login form -->
        </div>
      </div>
      <div class="col-lg-7">
        <div class="loginpageimg">
          <img src="<?php echo e(asset('/')); ?>images/login-page-banner.png" alt="">
        </div>
      </div>
    </div>
  </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bd\resources\views/auth/verify_otp.blade.php ENDPATH**/ ?>